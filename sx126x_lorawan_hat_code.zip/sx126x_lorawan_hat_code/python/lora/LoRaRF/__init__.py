# __init__.py
from .SX126x import SX126x
from .SX127x import SX127x
